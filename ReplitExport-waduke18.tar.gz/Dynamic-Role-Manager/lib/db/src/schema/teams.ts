import { pgTable, text, serial, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const teamsTable = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  problem: text("problem").notNull(),
  solution: text("solution").notNull(),
  marketSize: text("market_size").notNull(),
  revenueModel: text("revenue_model").notNull(),
  competitiveAdvantage: text("competitive_advantage").notNull(),
  confidenceScore: real("confidence_score").notNull().default(0),
  riskLevel: text("risk_level", { enum: ["low", "medium", "high", "extreme"] }).notNull().default("medium"),
  companyValue: real("company_value").notNull().default(1000000),
  totalFunding: real("total_funding").notNull().default(0),
  growthRate: real("growth_rate").notNull().default(0),
  status: text("status", { enum: ["active", "eliminated", "winner", "advanced"] }).notNull().default("active"),
  currentRound: integer("current_round").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTeamSchema = createInsertSchema(teamsTable).omit({ id: true, createdAt: true });
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teamsTable.$inferSelect;
