import { pgTable, text, serial, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const scoresTable = pgTable("scores", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  judgeId: integer("judge_id").notNull(),
  round: integer("round").notNull().default(1),
  ideaQuality: real("idea_quality").notNull(),
  marketOpportunity: real("market_opportunity").notNull(),
  businessModel: real("business_model").notNull(),
  competitiveAdvantage: real("competitive_advantage").notNull(),
  executionPlan: real("execution_plan").notNull(),
  presentation: real("presentation").notNull(),
  averageScore: real("average_score").notNull(),
  feedback: text("feedback"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertScoreSchema = createInsertSchema(scoresTable).omit({ id: true, createdAt: true });
export type InsertScore = z.infer<typeof insertScoreSchema>;
export type Score = typeof scoresTable.$inferSelect;
