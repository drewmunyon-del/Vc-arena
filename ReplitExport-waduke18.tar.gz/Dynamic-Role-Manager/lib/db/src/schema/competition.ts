import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const competitionStateTable = pgTable("competition_state", {
  id: serial("id").primaryKey(),
  currentRound: integer("current_round").notNull().default(1),
  maxRounds: integer("max_rounds").notNull().default(3),
  simulationIntensity: text("simulation_intensity", { enum: ["low", "medium", "high"] }).notNull().default("medium"),
  status: text("status", { enum: ["setup", "judging", "simulating", "results", "completed"] }).notNull().default("setup"),
  roundNames: text("round_names").notNull().default('["Round 1","Semifinals","Finals"]'),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCompetitionStateSchema = createInsertSchema(competitionStateTable).omit({ id: true, createdAt: true });
export type InsertCompetitionState = z.infer<typeof insertCompetitionStateSchema>;
export type CompetitionState = typeof competitionStateTable.$inferSelect;
