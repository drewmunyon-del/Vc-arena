import { pgTable, text, serial, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const simulationResultsTable = pgTable("simulation_results", {
  id: serial("id").primaryKey(),
  round: integer("round").notNull(),
  teamId: integer("team_id").notNull(),
  teamName: text("team_name").notNull(),
  funding: real("funding").notNull(),
  growthRate: real("growth_rate").notNull(),
  companyValue: real("company_value").notNull(),
  valueChange: real("value_change").notNull(),
  events: text("events").notNull().default("[]"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSimulationResultSchema = createInsertSchema(simulationResultsTable).omit({ id: true, createdAt: true });
export type InsertSimulationResult = z.infer<typeof insertSimulationResultSchema>;
export type SimulationResult = typeof simulationResultsTable.$inferSelect;
