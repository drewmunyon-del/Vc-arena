import { db, teamsTable, scoresTable, simulationResultsTable } from "@workspace/db";
import { eq, avg, inArray } from "drizzle-orm";
import { logger } from "./logger";

export interface TeamSimResult {
  teamId: number;
  teamName: string;
  funding: number;
  growthRate: number;
  companyValue: number;
  previousValue: number;
  valueChange: number;
  valueChangePercent: number;
  events: string[];
  failed: boolean;
}

export interface SimEvent {
  type: string;
  description: string;
  teamId: number | null;
  teamName: string | null;
  impact: "positive" | "negative" | "neutral";
  magnitude: number;
}

const EVENTS_POSITIVE = [
  { type: "Viral Growth Spike", description: "went viral on social media, user acquisition skyrocketed", impact: "positive" as const, baseMultiplier: 1.4 },
  { type: "Mega Investment", description: "received a surprise term sheet from a top-tier VC", impact: "positive" as const, baseMultiplier: 1.35 },
  { type: "Strategic Partnership", description: "signed a major distribution deal with an enterprise partner", impact: "positive" as const, baseMultiplier: 1.25 },
  { type: "Media Spotlight", description: "featured in TechCrunch and Forbes, brand awareness surged", impact: "positive" as const, baseMultiplier: 1.2 },
  { type: "Product-Market Fit", description: "found perfect product-market fit, retention shot through the roof", impact: "positive" as const, baseMultiplier: 1.3 },
  { type: "Celebrity Endorsement", description: "a major influencer went public with their endorsement", impact: "positive" as const, baseMultiplier: 1.22 },
  { type: "International Expansion", description: "broke into three new international markets simultaneously", impact: "positive" as const, baseMultiplier: 1.28 },
];

const EVENTS_NEGATIVE = [
  { type: "Investor Pullout", description: "lead investor pulled out citing market uncertainty", impact: "negative" as const, baseMultiplier: 0.55 },
  { type: "Market Crash", description: "sector-wide market crash wiped out valuations overnight", impact: "negative" as const, baseMultiplier: 0.45 },
  { type: "Competitor Emerges", description: "a well-funded competitor launched a near-identical product", impact: "negative" as const, baseMultiplier: 0.7 },
  { type: "Product Failure", description: "critical product bug caused mass user churn and PR disaster", impact: "negative" as const, baseMultiplier: 0.6 },
  { type: "Bad Press", description: "investigative journalism piece damaged brand reputation severely", impact: "negative" as const, baseMultiplier: 0.65 },
  { type: "Regulatory Crackdown", description: "new regulations froze operations in their core market", impact: "negative" as const, baseMultiplier: 0.58 },
  { type: "Key Team Exodus", description: "CTO and two lead engineers quit, citing culture issues", impact: "negative" as const, baseMultiplier: 0.72 },
  { type: "Security Breach", description: "major data breach exposed customer data, user trust collapsed", impact: "negative" as const, baseMultiplier: 0.5 },
  { type: "Slow Adoption", description: "user adoption far below projections despite heavy spend", impact: "negative" as const, baseMultiplier: 0.75 },
  { type: "Funding Wasted", description: "overspent on a failed marketing campaign with zero ROI", impact: "negative" as const, baseMultiplier: 0.68 },
];

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function getIntensityMultipliers(intensity: string): { swing: number; eventChance: number; badChance: number } {
  switch (intensity) {
    case "low":
      return { swing: 0.6, eventChance: 0.3, badChance: 0.35 };
    case "high":
      return { swing: 1.8, eventChance: 0.75, badChance: 0.55 };
    default: // medium
      return { swing: 1.1, eventChance: 0.55, badChance: 0.45 };
  }
}

export async function runSimulationEngine(round: number, intensity: string): Promise<{
  teamResults: TeamSimResult[];
  events: SimEvent[];
  winner: TeamSimResult;
  biggestLoser: TeamSimResult;
  mostFundingGained: TeamSimResult;
}> {
  const { swing, eventChance, badChance } = getIntensityMultipliers(intensity);

  const teams = await db.select().from(teamsTable).where(eq(teamsTable.status, "active"));

  if (teams.length === 0) {
    throw new Error("No active teams to simulate");
  }

  const allEvents: SimEvent[] = [];
  const teamResults: TeamSimResult[] = [];

  for (const team of teams) {
    const previousValue = team.companyValue;
    const teamEvents: string[] = [];

    // Base score multiplier from judging
    const scoreMultiplier = team.confidenceScore > 0
      ? (team.confidenceScore / 10) * 1.5 + 0.5 // 0.5 to 2.0 range
      : rand(0.7, 1.3);

    // Market conditions randomness — with LARGE swings
    const marketCondition = rand(0.6, 1.4) * swing;

    // Execution quality based on score + randomness
    const executionQuality = rand(0.5, 1.5) * scoreMultiplier;

    // Risk factor — higher risk = more extreme outcomes
    let riskFactor = 1.0;
    switch (team.riskLevel) {
      case "extreme": riskFactor = rand(0.2, 2.5); break;
      case "high": riskFactor = rand(0.3, 2.0); break;
      case "medium": riskFactor = rand(0.5, 1.7); break;
      case "low": riskFactor = rand(0.7, 1.4); break;
    }

    // Random events with big impact
    let eventMultiplier = 1.0;

    if (Math.random() < eventChance) {
      const isBadEvent = Math.random() < badChance;
      if (isBadEvent) {
        const event = EVENTS_NEGATIVE[Math.floor(Math.random() * EVENTS_NEGATIVE.length)];
        // Add variance to event magnitude based on intensity
        const magnitude = event.baseMultiplier * rand(0.7, 1.3) * (1 / swing);
        eventMultiplier *= magnitude;
        const eventEntry: SimEvent = {
          type: event.type,
          description: `${team.name} ${event.description}`,
          teamId: team.id,
          teamName: team.name,
          impact: event.impact,
          magnitude: Math.abs(1 - magnitude),
        };
        allEvents.push(eventEntry);
        teamEvents.push(event.type);
      } else {
        const event = EVENTS_POSITIVE[Math.floor(Math.random() * EVENTS_POSITIVE.length)];
        const magnitude = event.baseMultiplier * rand(0.8, 1.4) * swing;
        eventMultiplier *= magnitude;
        const eventEntry: SimEvent = {
          type: event.type,
          description: `${team.name} ${event.description}`,
          teamId: team.id,
          teamName: team.name,
          impact: event.impact,
          magnitude: Math.abs(magnitude - 1),
        };
        allEvents.push(eventEntry);
        teamEvents.push(event.type);
      }
    }

    // Second event possibility for high intensity
    if (intensity === "high" && Math.random() < 0.3) {
      const isBadEvent = Math.random() < 0.5;
      if (isBadEvent) {
        const event = EVENTS_NEGATIVE[Math.floor(Math.random() * EVENTS_NEGATIVE.length)];
        const magnitude = event.baseMultiplier * rand(0.8, 1.2);
        eventMultiplier *= magnitude;
        teamEvents.push(event.type);
      } else {
        const event = EVENTS_POSITIVE[Math.floor(Math.random() * EVENTS_POSITIVE.length)];
        const magnitude = event.baseMultiplier * rand(0.9, 1.2);
        eventMultiplier *= magnitude;
        teamEvents.push(event.type);
      }
    }

    // Calculate funding this round
    const baseFunding = team.confidenceScore > 0
      ? team.confidenceScore * 200000 * marketCondition
      : rand(50000, 500000);
    const funding = Math.max(0, baseFunding * riskFactor * eventMultiplier);

    // Calculate growth rate — can be very negative
    const growthRate = (
      (scoreMultiplier - 1) * 30 +
      (marketCondition - 1) * 40 +
      (executionQuality - 1) * 25 +
      (riskFactor - 1) * 20 +
      (eventMultiplier - 1) * 35 +
      rand(-15, 15)
    );

    // Calculate new company value
    const totalMultiplier = marketCondition * executionQuality * riskFactor * eventMultiplier;
    let newValue = previousValue * Math.max(0.05, totalMultiplier);

    // Add funding boost to value
    newValue += funding * 0.3;

    // Ensure some teams can completely fail
    const failed = newValue < previousValue * 0.1 || (team.riskLevel === "extreme" && Math.random() < 0.1);
    if (failed) {
      newValue = previousValue * rand(0.02, 0.08);
      teamEvents.push("Company Near-Collapse");
    }

    const valueChange = newValue - previousValue;
    const valueChangePercent = (valueChange / previousValue) * 100;

    // Update team in DB
    await db
      .update(teamsTable)
      .set({
        companyValue: Math.round(newValue),
        totalFunding: team.totalFunding + funding,
        growthRate: Math.round(growthRate * 100) / 100,
        currentRound: round,
      })
      .where(eq(teamsTable.id, team.id));

    // Save result to DB
    await db.insert(simulationResultsTable).values({
      round,
      teamId: team.id,
      teamName: team.name,
      funding: Math.round(funding),
      growthRate: Math.round(growthRate * 100) / 100,
      companyValue: Math.round(newValue),
      valueChange: Math.round(valueChange),
      events: JSON.stringify(teamEvents),
    });

    teamResults.push({
      teamId: team.id,
      teamName: team.name,
      funding: Math.round(funding),
      growthRate: Math.round(growthRate * 100) / 100,
      companyValue: Math.round(newValue),
      previousValue: Math.round(previousValue),
      valueChange: Math.round(valueChange),
      valueChangePercent: Math.round(valueChangePercent * 100) / 100,
      events: teamEvents,
      failed,
    });
  }

  // Add 1-2 global market events
  if (Math.random() < 0.4) {
    allEvents.unshift({
      type: "Global Market Shift",
      description: "Global startup ecosystem experienced significant volatility this round",
      teamId: null,
      teamName: null,
      impact: Math.random() < 0.5 ? "positive" : "negative",
      magnitude: rand(0.1, 0.5),
    });
  }

  // Sort for results
  const sorted = [...teamResults].sort((a, b) => b.valueChangePercent - a.valueChangePercent);
  const winner = sorted[0];
  const biggestLoser = sorted[sorted.length - 1];
  const mostFundingGained = [...teamResults].sort((a, b) => b.funding - a.funding)[0];

  logger.info({ round, teamCount: teams.length }, "Simulation completed");

  return { teamResults, events: allEvents, winner, biggestLoser, mostFundingGained };
}
