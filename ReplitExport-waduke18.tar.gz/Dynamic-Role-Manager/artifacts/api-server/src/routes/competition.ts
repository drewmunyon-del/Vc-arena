import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, competitionStateTable, teamsTable, scoresTable, simulationResultsTable } from "@workspace/db";
import { UpdateCompetitionStateBody } from "@workspace/api-zod";

function serialize(row: any) {
  const out: any = { ...row };
  for (const key of Object.keys(out)) {
    if (out[key] instanceof Date) out[key] = out[key].toISOString();
  }
  return out;
}

const router: IRouter = Router();

async function ensureCompetitionState() {
  const existing = await db.select().from(competitionStateTable).limit(1);
  if (existing.length === 0) {
    const [state] = await db.insert(competitionStateTable).values({
      currentRound: 1,
      maxRounds: 3,
      simulationIntensity: "medium",
      status: "setup",
      roundNames: JSON.stringify(["Round 1", "Semifinals", "Finals"]),
    }).returning();
    return state;
  }
  return existing[0];
}

router.get("/competition/state", async (_req, res): Promise<void> => {
  const state = await ensureCompetitionState();
  res.json(serialize(state));
});

router.patch("/competition/state", async (req, res): Promise<void> => {
  const parsed = UpdateCompetitionStateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const state = await ensureCompetitionState();
  const [updated] = await db
    .update(competitionStateTable)
    .set(parsed.data)
    .where(eq(competitionStateTable.id, state.id))
    .returning();

  res.json(serialize(updated));
});

router.post("/competition/reset", async (_req, res): Promise<void> => {
  await db.update(teamsTable).set({
    companyValue: 1000000,
    totalFunding: 0,
    growthRate: 0,
    status: "active",
    currentRound: 1,
    confidenceScore: 0,
  });

  await db.delete(scoresTable);
  await db.delete(simulationResultsTable);

  const existing = await db.select().from(competitionStateTable).limit(1);
  if (existing.length > 0) {
    await db.update(competitionStateTable)
      .set({ currentRound: 1, status: "setup" })
      .where(eq(competitionStateTable.id, existing[0].id));
  }

  res.json({ success: true, message: "Competition reset successfully" });
});

export default router;
