import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, simulationResultsTable } from "@workspace/db";
import {
  RunSimulationBody,
  ListSimulationResultsQueryParams,
} from "@workspace/api-zod";
import { runSimulationEngine } from "../lib/simulation";

function serialize(row: any) {
  const out: any = { ...row };
  for (const key of Object.keys(out)) {
    if (out[key] instanceof Date) out[key] = out[key].toISOString();
  }
  return out;
}

const router: IRouter = Router();

router.post("/simulation/run", async (req, res): Promise<void> => {
  const parsed = RunSimulationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = await runSimulationEngine(parsed.data.round, parsed.data.intensity);

  const response = {
    round: parsed.data.round,
    teamResults: result.teamResults,
    events: result.events,
    winner: result.winner,
    biggestLoser: result.biggestLoser,
    mostFundingGained: result.mostFundingGained,
  };

  res.json(response);
});

router.get("/simulation/results", async (req, res): Promise<void> => {
  const params = ListSimulationResultsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  let query = db.select().from(simulationResultsTable).$dynamic();
  if (params.data.round) {
    query = query.where(eq(simulationResultsTable.round, params.data.round));
  }
  const results = await query.orderBy(simulationResultsTable.createdAt);
  res.json(results.map(serialize));
});

export default router;
