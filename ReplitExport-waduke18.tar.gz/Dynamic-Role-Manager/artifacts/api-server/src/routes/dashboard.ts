import { Router, type IRouter } from "express";
import { db, teamsTable, competitionStateTable, simulationResultsTable } from "@workspace/db";
import { desc, asc } from "drizzle-orm";

const router: IRouter = Router();

function serializeTeam(t: any) {
  return {
    id: t.id,
    name: t.name,
    companyValue: Number(t.companyValue),
    growthRate: Number(t.growthRate),
    totalFunding: Number(t.totalFunding),
    confidenceScore: Number(t.confidenceScore),
    status: t.status,
    riskLevel: t.riskLevel,
    currentRound: t.currentRound,
  };
}

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const teams = await db.select().from(teamsTable);
  const activeTeams = teams.filter((t) => t.status === "active" || t.status === "advanced");
  const eliminatedTeams = teams.filter((t) => t.status === "eliminated");

  const totalFunding = teams.reduce((sum, t) => sum + Number(t.totalFunding), 0);
  const avgValue = teams.length > 0 ? teams.reduce((sum, t) => sum + Number(t.companyValue), 0) / teams.length : 0;

  const sortedByValue = [...teams].sort((a, b) => Number(b.companyValue) - Number(a.companyValue));
  const sortedByGrowth = [...activeTeams].sort((a, b) => Number(b.growthRate) - Number(a.growthRate));
  const sortedByLoss = [...teams].sort((a, b) => Number(a.growthRate) - Number(b.growthRate));
  const sortedByVolatility = [...teams].sort((a, b) => Math.abs(Number(b.growthRate)) - Math.abs(Number(a.growthRate)));

  const compState = await db.select().from(competitionStateTable).limit(1);

  const summary = {
    totalTeams: teams.length,
    activeTeams: activeTeams.length,
    eliminatedTeams: eliminatedTeams.length,
    totalFundingRaised: Math.round(totalFunding),
    averageCompanyValue: Math.round(avgValue),
    topTeam: sortedByValue[0] ? serializeTeam(sortedByValue[0]) : null,
    fastestGrowth: sortedByGrowth[0] ? serializeTeam(sortedByGrowth[0]) : null,
    biggestLoss: sortedByLoss[0] ? serializeTeam(sortedByLoss[0]) : null,
    mostVolatile: sortedByVolatility[0] ? serializeTeam(sortedByVolatility[0]) : null,
    currentRound: compState[0]?.currentRound ?? 1,
    competitionStatus: compState[0]?.status ?? "setup",
  };

  res.json(summary);
});

router.get("/dashboard/leaderboard", async (_req, res): Promise<void> => {
  const teams = await db.select().from(teamsTable).orderBy(desc(teamsTable.companyValue));

  const prevResults = await db
    .select()
    .from(simulationResultsTable)
    .orderBy(asc(simulationResultsTable.createdAt));

  const prevValueMap: Record<number, number> = {};
  for (const result of prevResults) {
    prevValueMap[result.teamId] = Number(result.companyValue);
  }

  const leaderboard = teams.map((team, index) => {
    const rank = index + 1;
    const prevValue = prevValueMap[team.id];

    let previousRank: number | null = null;
    let rankChange: number | null = null;

    if (prevValue !== undefined) {
      const prevSorted = teams
        .map((t) => ({ id: t.id, prevVal: prevValueMap[t.id] ?? Number(t.companyValue) }))
        .sort((a, b) => b.prevVal - a.prevVal);
      const prevRankIndex = prevSorted.findIndex((t) => t.id === team.id);
      if (prevRankIndex >= 0) {
        previousRank = prevRankIndex + 1;
        rankChange = previousRank - rank;
      }
    }

    return {
      rank,
      previousRank,
      rankChange,
      teamId: team.id,
      teamName: team.name,
      companyValue: Number(team.companyValue),
      growthRate: Number(team.growthRate),
      totalFunding: Number(team.totalFunding),
      status: team.status,
    };
  });

  res.json(leaderboard);
});

export default router;
