import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import teamsRouter from "./teams";
import scoresRouter from "./scores";
import simulationRouter from "./simulation";
import competitionRouter from "./competition";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(teamsRouter);
router.use(scoresRouter);
router.use(simulationRouter);
router.use(competitionRouter);
router.use(dashboardRouter);

export default router;
