import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, scoresTable, teamsTable } from "@workspace/db";
import {
  CreateScoreBody,
  UpdateScoreParams,
  UpdateScoreBody,
  ListScoresQueryParams,
} from "@workspace/api-zod";

function serialize(row: any) {
  const out: any = { ...row };
  for (const key of Object.keys(out)) {
    if (out[key] instanceof Date) out[key] = out[key].toISOString();
  }
  return out;
}

const router: IRouter = Router();

router.get("/scores", async (req, res): Promise<void> => {
  const params = ListScoresQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  let query = db.select().from(scoresTable).$dynamic();
  if (params.data.teamId) {
    query = query.where(eq(scoresTable.teamId, params.data.teamId));
  }
  const scores = await query.orderBy(scoresTable.createdAt);
  res.json(scores.map(serialize));
});

router.post("/scores", async (req, res): Promise<void> => {
  const parsed = CreateScoreBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const avg = (
    parsed.data.ideaQuality +
    parsed.data.marketOpportunity +
    parsed.data.businessModel +
    parsed.data.competitiveAdvantage +
    parsed.data.executionPlan +
    parsed.data.presentation
  ) / 6;

  const [score] = await db.insert(scoresTable).values({
    ...parsed.data,
    averageScore: Math.round(avg * 100) / 100,
  }).returning();

  const allScores = await db.select().from(scoresTable).where(eq(scoresTable.teamId, parsed.data.teamId));
  const confidenceScore = allScores.reduce((sum, s) => sum + s.averageScore, 0) / allScores.length;

  await db
    .update(teamsTable)
    .set({ confidenceScore: Math.round(confidenceScore * 100) / 100 })
    .where(eq(teamsTable.id, parsed.data.teamId));

  res.status(201).json(serialize(score));
});

router.patch("/scores/:id", async (req, res): Promise<void> => {
  const params = UpdateScoreParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateScoreBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const existing = await db.select().from(scoresTable).where(eq(scoresTable.id, params.data.id));
  if (!existing[0]) {
    res.status(404).json({ error: "Score not found" });
    return;
  }

  const merged = { ...existing[0], ...parsed.data };
  const avg = (
    merged.ideaQuality +
    merged.marketOpportunity +
    merged.businessModel +
    merged.competitiveAdvantage +
    merged.executionPlan +
    merged.presentation
  ) / 6;

  const [score] = await db
    .update(scoresTable)
    .set({ ...parsed.data, averageScore: Math.round(avg * 100) / 100 })
    .where(eq(scoresTable.id, params.data.id))
    .returning();

  res.json(serialize(score));
});

export default router;
