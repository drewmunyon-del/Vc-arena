import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppLayout } from "@/components/layout";
import { LoginPage } from "@/pages/login";
import { Dashboard } from "@/pages/dashboard";
import { TeamsPage } from "@/pages/teams";
import { TeamDetail } from "@/pages/team-detail";
import { JudgePage } from "@/pages/judge";
import { SimulationPage } from "@/pages/simulation";
import { LeaderboardPage } from "@/pages/leaderboard";
import { AdminPanel } from "@/pages/admin";
import { UsersPage } from "@/pages/users";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 5000,
    },
  },
});

function ProtectedRoute({ component: Component, allowedRoles }: { component: React.ComponentType; allowedRoles: string[] }) {
  const { currentUser } = useAuth();
  if (!currentUser || !allowedRoles.includes(currentUser.role)) {
    return <Redirect to="/" />;
  }
  return <Component />;
}

function AppRoutes() {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return (
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route>
          <Redirect to="/login" />
        </Route>
      </Switch>
    );
  }

  return (
    <AppLayout>
      <Switch>
        <Route path="/login">
          <Redirect to="/" />
        </Route>
        <Route path="/" component={Dashboard} />
        <Route path="/teams" component={TeamsPage} />
        <Route path="/teams/:id" component={TeamDetail} />
        <Route path="/judge">
          <ProtectedRoute component={JudgePage} allowedRoles={["admin", "judge"]} />
        </Route>
        <Route path="/simulation" component={SimulationPage} />
        <Route path="/leaderboard" component={LeaderboardPage} />
        <Route path="/admin">
          <ProtectedRoute component={AdminPanel} allowedRoles={["admin"]} />
        </Route>
        <Route path="/users">
          <ProtectedRoute component={UsersPage} allowedRoles={["admin"]} />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <AppRoutes />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
