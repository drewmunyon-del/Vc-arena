import { useGetDashboardSummary, useGetCompetitionState } from "@workspace/api-client-react";
import { TrendingUp, TrendingDown, Zap, DollarSign, Building2, Target, AlertTriangle, Trophy } from "lucide-react";
import { Link } from "wouter";

function formatValue(v: number) {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

const statusColors: Record<string, string> = {
  setup: "text-muted-foreground",
  judging: "text-purple-400",
  simulating: "text-amber-400",
  results: "text-cyan-400",
  completed: "text-green-400",
};

export function Dashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary();
  const { data: competition } = useGetCompetitionState();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const spotlights = [
    {
      label: "Top Company",
      team: summary?.topTeam,
      icon: Trophy,
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/20",
    },
    {
      label: "Fastest Growth",
      team: summary?.fastestGrowth,
      icon: TrendingUp,
      color: "text-green-400",
      bg: "bg-green-500/10 border-green-500/20",
    },
    {
      label: "Biggest Loss",
      team: summary?.biggestLoss,
      icon: TrendingDown,
      color: "text-red-400",
      bg: "bg-red-500/10 border-red-500/20",
    },
    {
      label: "Most Volatile",
      team: summary?.mostVolatile,
      icon: Zap,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10 border-cyan-500/20",
    },
  ];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Live Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Round {summary?.currentRound} — Status:{" "}
            <span className={`font-medium capitalize ${statusColors[summary?.competitionStatus ?? "setup"]}`}>
              {summary?.competitionStatus?.replace("_", " ")}
            </span>
          </p>
        </div>
        <Link href="/leaderboard">
          <button className="px-4 py-2 text-sm rounded-lg bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 transition-all">
            View Leaderboard
          </button>
        </Link>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Teams", value: summary?.totalTeams ?? 0, icon: Building2, color: "text-primary" },
          { label: "Active Teams", value: summary?.activeTeams ?? 0, icon: Target, color: "text-green-400" },
          { label: "Eliminated", value: summary?.eliminatedTeams ?? 0, icon: AlertTriangle, color: "text-red-400" },
          { label: "Total Funding", value: formatValue(summary?.totalFundingRaised ?? 0), icon: DollarSign, color: "text-amber-400" },
        ].map(stat => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${stat.color}`} />
                <span className="text-xs text-muted-foreground">{stat.label}</span>
              </div>
              <div className="text-2xl font-bold text-foreground">{stat.value}</div>
            </div>
          );
        })}
      </div>

      {/* Avg value */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="text-sm text-muted-foreground mb-1">Average Company Value</div>
        <div className="text-3xl font-bold text-primary">{formatValue(summary?.averageCompanyValue ?? 0)}</div>
      </div>

      {/* Spotlight teams */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Spotlights</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {spotlights.map(({ label, team, icon: Icon, color, bg }) => (
            <div key={label} className={`rounded-xl border p-4 ${bg}`}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${color}`} />
                <span className={`text-xs font-semibold uppercase tracking-wider ${color}`}>{label}</span>
              </div>
              {team ? (
                <Link href={`/teams/${team.id}`}>
                  <div className="cursor-pointer hover:opacity-80 transition-opacity">
                    <div className="font-bold text-lg text-foreground">{team.name}</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Value: <span className="text-foreground font-medium">{formatValue(team.companyValue)}</span>
                      {" · "}
                      Growth: <span className={`font-medium ${team.growthRate >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {team.growthRate >= 0 ? "+" : ""}{team.growthRate.toFixed(1)}%
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 capitalize">{team.status}</div>
                  </div>
                </Link>
              ) : (
                <div className="text-muted-foreground text-sm">No data yet</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Competition info */}
      {competition && (
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-foreground">Competition Progress</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Round {competition.currentRound} of {competition.maxRounds} · Intensity:{" "}
                <span className={`capitalize font-medium ${
                  competition.simulationIntensity === "high" ? "text-red-400" :
                  competition.simulationIntensity === "low" ? "text-green-400" : "text-amber-400"
                }`}>{competition.simulationIntensity}</span>
              </div>
            </div>
            <div className="flex gap-1">
              {Array.from({ length: competition.maxRounds }).map((_, i) => (
                <div key={i} className={`h-2 w-8 rounded-full ${
                  i < competition.currentRound ? "bg-primary" : "bg-border"
                }`} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
