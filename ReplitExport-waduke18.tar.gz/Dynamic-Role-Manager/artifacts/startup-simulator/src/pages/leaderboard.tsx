import { useGetLeaderboard } from "@workspace/api-client-react";
import { TrendingUp, TrendingDown, Minus, Trophy } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

function formatValue(v: number) {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

const statusBadge: Record<string, string> = {
  active: "bg-green-500/15 text-green-400 border-green-500/30",
  eliminated: "bg-red-500/15 text-red-400 border-red-500/30",
  winner: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  advanced: "bg-cyan-500/15 text-cyan-400 border-cyan-500/30",
};

function RankChange({ change }: { change: number | null | undefined }) {
  if (change === null || change === undefined) return <span className="text-xs text-muted-foreground">NEW</span>;
  if (change === 0) return <Minus className="w-3 h-3 text-muted-foreground" />;
  if (change > 0) return (
    <span className="flex items-center gap-0.5 text-green-400 text-xs font-bold">
      <TrendingUp className="w-3 h-3" />+{change}
    </span>
  );
  return (
    <span className="flex items-center gap-0.5 text-red-400 text-xs font-bold">
      <TrendingDown className="w-3 h-3" />{change}
    </span>
  );
}

export function LeaderboardPage() {
  const { data: leaderboard, isLoading } = useGetLeaderboard();

  const rankEmojis: Record<number, React.ElementType | null> = {
    1: Trophy,
    2: null,
    3: null,
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Leaderboard</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Ranked by company value</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-2">
          {leaderboard?.map((entry, idx) => {
            const TrophyIcon = rankEmojis[entry.rank];
            return (
              <div
                key={entry.teamId}
                className={cn(
                  "bg-card border rounded-xl p-4 flex items-center gap-4 transition-all hover:border-primary/30",
                  entry.rank === 1 ? "border-amber-500/40 bg-amber-500/5 animate-winner-glow" :
                  entry.status === "eliminated" ? "border-red-500/20 opacity-60" :
                  "border-border"
                )}
              >
                {/* Rank */}
                <div className="w-10 text-center flex-shrink-0">
                  {TrophyIcon ? (
                    <TrophyIcon className="w-5 h-5 text-amber-400 mx-auto" />
                  ) : (
                    <span className={cn(
                      "text-lg font-black",
                      entry.rank <= 3 ? "text-foreground" : "text-muted-foreground"
                    )}>{entry.rank}</span>
                  )}
                </div>

                {/* Rank change */}
                <div className="w-12 flex-shrink-0 flex items-center justify-center">
                  <RankChange change={entry.rankChange} />
                </div>

                {/* Team info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Link href={`/teams/${entry.teamId}`}>
                      <span className="font-semibold text-foreground hover:text-primary cursor-pointer transition-colors">
                        {entry.teamName}
                      </span>
                    </Link>
                    <Badge className={cn("text-xs border capitalize", statusBadge[entry.status])}>
                      {entry.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-xs text-muted-foreground">
                      Funding: <span className="text-foreground">{formatValue(entry.totalFunding)}</span>
                    </span>
                  </div>
                </div>

                {/* Value & growth */}
                <div className="text-right flex-shrink-0">
                  <div className="font-bold text-primary text-lg">{formatValue(entry.companyValue)}</div>
                  <div className={cn(
                    "text-sm flex items-center justify-end gap-0.5",
                    entry.growthRate >= 0 ? "text-green-400" : "text-red-400"
                  )}>
                    {entry.growthRate >= 0
                      ? <TrendingUp className="w-3 h-3" />
                      : <TrendingDown className="w-3 h-3" />
                    }
                    {entry.growthRate >= 0 ? "+" : ""}{entry.growthRate.toFixed(1)}%
                  </div>
                </div>
              </div>
            );
          })}

          {(!leaderboard || leaderboard.length === 0) && (
            <div className="text-center py-12 text-muted-foreground">
              No teams on the leaderboard yet.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
