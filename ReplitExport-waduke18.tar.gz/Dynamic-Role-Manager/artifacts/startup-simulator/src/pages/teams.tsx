import { useState } from "react";
import {
  useListTeams, useCreateTeam, useDeleteTeam, useUpdateTeam,
  useAdvanceTeam, useEliminateTeam,
  getListTeamsQueryKey
} from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Plus, Trash2, ChevronUp, ChevronDown, Edit2, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

function formatValue(v: number) {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

const statusBadge: Record<string, string> = {
  active: "bg-green-500/15 text-green-400 border-green-500/30",
  eliminated: "bg-red-500/15 text-red-400 border-red-500/30",
  winner: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  advanced: "bg-cyan-500/15 text-cyan-400 border-cyan-500/30",
};

const riskBadge: Record<string, string> = {
  low: "bg-green-500/10 text-green-400",
  medium: "bg-amber-500/10 text-amber-400",
  high: "bg-orange-500/10 text-orange-400",
  extreme: "bg-red-500/10 text-red-400",
};

function AddTeamModal({ onClose }: { onClose: () => void }) {
  const queryClient = useQueryClient();
  const createTeam = useCreateTeam();
  const [form, setForm] = useState({
    name: "", problem: "", solution: "", marketSize: "",
    revenueModel: "", competitiveAdvantage: "", riskLevel: "medium" as "low" | "medium" | "high" | "extreme"
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await createTeam.mutateAsync({ data: form });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-lg animate-slide-up">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">Add New Team</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          {[
            { key: "name", label: "Team Name" },
            { key: "problem", label: "Problem" },
            { key: "solution", label: "Solution" },
            { key: "marketSize", label: "Market Size" },
            { key: "revenueModel", label: "Revenue Model" },
            { key: "competitiveAdvantage", label: "Competitive Advantage" },
          ].map(({ key, label }) => (
            <div key={key}>
              <label className="text-xs text-muted-foreground font-medium mb-1 block">{label}</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                value={form[key as keyof typeof form]}
                onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                required
              />
            </div>
          ))}
          <div>
            <label className="text-xs text-muted-foreground font-medium mb-1 block">Risk Level</label>
            <select
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              value={form.riskLevel}
              onChange={e => setForm(f => ({ ...f, riskLevel: e.target.value as any }))}
            >
              {["low", "medium", "high", "extreme"].map(r => (
                <option key={r} value={r} className="capitalize">{r}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
            <Button type="submit" className="flex-1" disabled={createTeam.isPending}>
              {createTeam.isPending ? "Creating..." : "Create Team"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function TeamsPage() {
  const { currentUser } = useAuth();
  const { data: teams, isLoading } = useListTeams();
  const deleteTeam = useDeleteTeam();
  const advanceTeam = useAdvanceTeam();
  const eliminateTeam = useEliminateTeam();
  const queryClient = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const isAdmin = currentUser?.role === "admin";

  async function handleDelete(id: number) {
    if (!confirm("Delete this team?")) return;
    await deleteTeam.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
  }

  async function handleAdvance(id: number) {
    await advanceTeam.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
  }

  async function handleEliminate(id: number) {
    await eliminateTeam.mutateAsync({ id });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
  }

  const sorted = [...(teams ?? [])].sort((a, b) => b.companyValue - a.companyValue);

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Teams</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{teams?.length ?? 0} startups competing</p>
        </div>
        {isAdmin && (
          <Button onClick={() => setShowAdd(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            Add Team
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid gap-3">
          {sorted.map((team, idx) => (
            <div key={team.id} className="bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-all">
              <div className="flex items-center gap-3">
                <div className="text-2xl font-bold text-muted-foreground w-8 text-center">
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Link href={`/teams/${team.id}`}>
                      <span className="font-semibold text-foreground hover:text-primary cursor-pointer transition-colors">{team.name}</span>
                    </Link>
                    <Badge className={cn("text-xs border capitalize", statusBadge[team.status])}>
                      {team.status}
                    </Badge>
                    <Badge className={cn("text-xs capitalize", riskBadge[team.riskLevel])}>
                      {team.riskLevel} risk
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1 truncate">{team.problem}</div>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="text-sm font-bold text-primary">{formatValue(team.companyValue)}</span>
                    <span className={`text-xs flex items-center gap-0.5 ${team.growthRate >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {team.growthRate >= 0 ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      {Math.abs(team.growthRate).toFixed(1)}%
                    </span>
                    <span className="text-xs text-muted-foreground">Confidence: {team.confidenceScore.toFixed(1)}/10</span>
                  </div>
                </div>
                {isAdmin && (
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {team.status === "active" && (
                      <>
                        <button
                          onClick={() => handleAdvance(team.id)}
                          className="p-1.5 text-cyan-400 hover:bg-cyan-500/10 rounded transition-all"
                          title="Advance team"
                        >
                          <ChevronUp className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEliminate(team.id)}
                          className="p-1.5 text-red-400 hover:bg-red-500/10 rounded transition-all"
                          title="Eliminate team"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    )}
                    <Link href={`/teams/${team.id}`}>
                      <button className="p-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded transition-all">
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </Link>
                    <button
                      onClick={() => handleDelete(team.id)}
                      className="p-1.5 text-muted-foreground hover:text-red-400 hover:bg-red-500/10 rounded transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {sorted.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No teams yet. {isAdmin && "Add the first team to get started."}
            </div>
          )}
        </div>
      )}

      {showAdd && <AddTeamModal onClose={() => setShowAdd(false)} />}
    </div>
  );
}
