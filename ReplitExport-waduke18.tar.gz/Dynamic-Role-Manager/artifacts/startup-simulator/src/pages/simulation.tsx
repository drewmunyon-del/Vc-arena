import { useState } from "react";
import { useRunSimulation, useListSimulationResults, useGetCompetitionState, getListSimulationResultsQueryKey, getGetDashboardSummaryQueryKey, getGetLeaderboardQueryKey, getListTeamsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { TrendingUp, TrendingDown, Zap, Trophy, Skull, DollarSign, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

function formatValue(v: number) {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

const eventTypeColors: Record<string, string> = {
  "Viral Growth Spike": "bg-green-500/20 text-green-400 border-green-500/30",
  "Mega Investment": "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  "Strategic Partnership": "bg-blue-500/20 text-blue-400 border-blue-500/30",
  "Media Spotlight": "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "Product-Market Fit": "bg-teal-500/20 text-teal-400 border-teal-500/30",
  "Celebrity Endorsement": "bg-pink-500/20 text-pink-400 border-pink-500/30",
  "International Expansion": "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
  "Investor Pullout": "bg-red-500/20 text-red-400 border-red-500/30",
  "Market Crash": "bg-red-800/30 text-red-300 border-red-700/40",
  "Competitor Emerges": "bg-orange-500/20 text-orange-400 border-orange-500/30",
  "Product Failure": "bg-red-600/20 text-red-400 border-red-600/30",
  "Bad Press": "bg-orange-600/20 text-orange-400 border-orange-600/30",
  "Regulatory Crackdown": "bg-yellow-600/20 text-yellow-400 border-yellow-600/30",
  "Key Team Exodus": "bg-rose-500/20 text-rose-400 border-rose-500/30",
  "Security Breach": "bg-red-700/30 text-red-300 border-red-700/40",
  "Slow Adoption": "bg-amber-600/20 text-amber-400 border-amber-600/30",
  "Funding Wasted": "bg-orange-700/20 text-orange-400 border-orange-700/30",
  "Company Near-Collapse": "bg-red-900/40 text-red-300 border-red-800/50",
  "Global Market Shift": "bg-slate-500/20 text-slate-400 border-slate-500/30",
};

function EventBadge({ type }: { type: string }) {
  const cls = eventTypeColors[type] ?? "bg-muted text-muted-foreground border-border";
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${cls}`}>{type}</span>
  );
}

export function SimulationPage() {
  const { currentUser } = useAuth();
  const { data: competition } = useGetCompetitionState();
  const runSimulation = useRunSimulation();
  const { data: results } = useListSimulationResults();
  const queryClient = useQueryClient();
  const isAdmin = currentUser?.role === "admin";

  const [simResult, setSimResult] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showReveal, setShowReveal] = useState(false);

  async function handleRunSimulation() {
    if (!competition) return;
    setIsRunning(true);
    setSimResult(null);
    setShowReveal(false);

    await new Promise(r => setTimeout(r, 800)); // dramatic pause

    const result = await runSimulation.mutateAsync({
      data: {
        round: competition.currentRound,
        intensity: competition.simulationIntensity,
      }
    });

    setSimResult(result);
    setShowReveal(true);
    setIsRunning(false);

    // Invalidate everything
    queryClient.invalidateQueries({ queryKey: getListSimulationResultsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
  }

  const sortedResults = simResult?.teamResults
    ? [...simResult.teamResults].sort((a: any, b: any) => b.valueChangePercent - a.valueChangePercent)
    : [];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Simulation Engine</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Round {competition?.currentRound} · Intensity:{" "}
          <span className={`font-medium capitalize ${
            competition?.simulationIntensity === "high" ? "text-red-400" :
            competition?.simulationIntensity === "low" ? "text-green-400" : "text-amber-400"
          }`}>{competition?.simulationIntensity}</span>
        </p>
      </div>

      {/* RUN SIMULATION button */}
      {isAdmin && (
        <div className="flex justify-center">
          <button
            onClick={handleRunSimulation}
            disabled={isRunning || runSimulation.isPending}
            className={cn(
              "relative px-12 py-5 rounded-2xl text-xl font-bold transition-all duration-300 overflow-hidden",
              isRunning
                ? "bg-amber-500/20 border-2 border-amber-500/50 text-amber-400 cursor-wait animate-pulse"
                : "bg-primary/10 border-2 border-primary/50 text-primary hover:bg-primary/20 hover:border-primary animate-pulse-glow cursor-pointer"
            )}
          >
            <div className="flex items-center gap-3">
              <Zap className={`w-6 h-6 ${isRunning ? "animate-spin" : ""}`} />
              {isRunning ? "SIMULATING..." : "RUN SIMULATION"}
            </div>
          </button>
        </div>
      )}

      {/* Reveal results */}
      {showReveal && simResult && (
        <div className="space-y-6 animate-slide-up">
          {/* Winner / Loser highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 animate-winner-glow">
              <div className="flex items-center gap-2 mb-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Biggest Winner</span>
              </div>
              <div className="text-lg font-bold text-foreground">{simResult.winner?.teamName}</div>
              <div className="text-2xl font-black text-green-400 mt-1">
                +{simResult.winner?.valueChangePercent?.toFixed(1)}%
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {formatValue(simResult.winner?.previousValue)} → {formatValue(simResult.winner?.companyValue)}
              </div>
            </div>

            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 animate-loser-shake">
              <div className="flex items-center gap-2 mb-2">
                <Skull className="w-5 h-5 text-red-400" />
                <span className="text-xs font-bold text-red-400 uppercase tracking-wider">Biggest Crash</span>
              </div>
              <div className="text-lg font-bold text-foreground">{simResult.biggestLoser?.teamName}</div>
              <div className="text-2xl font-black text-red-400 mt-1">
                {simResult.biggestLoser?.valueChangePercent?.toFixed(1)}%
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {formatValue(simResult.biggestLoser?.previousValue)} → {formatValue(simResult.biggestLoser?.companyValue)}
              </div>
            </div>

            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-5 h-5 text-cyan-400" />
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Most Funding</span>
              </div>
              <div className="text-lg font-bold text-foreground">{simResult.mostFundingGained?.teamName}</div>
              <div className="text-2xl font-black text-cyan-400 mt-1">
                {formatValue(simResult.mostFundingGained?.funding)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">raised this round</div>
            </div>
          </div>

          {/* Events */}
          {simResult.events?.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-5">
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Events This Round</h2>
              <div className="space-y-2">
                {simResult.events.map((event: any, i: number) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-background border border-border">
                    <div className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${event.impact === "positive" ? "bg-green-400" : event.impact === "negative" ? "bg-red-400" : "bg-muted-foreground"}`} />
                    <div>
                      <EventBadge type={event.type} />
                      <p className="text-sm text-foreground/80 mt-1">{event.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All team results */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Team Results</h2>
            <div className="grid gap-3">
              {sortedResults.map((team: any, idx: number) => (
                <div
                  key={team.teamId}
                  className={cn(
                    "rounded-xl border p-4 transition-all",
                    idx === 0 ? "border-amber-500/30 bg-amber-500/5" :
                    idx === sortedResults.length - 1 ? "border-red-500/30 bg-red-500/5" :
                    "border-border bg-card"
                  )}
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-bold text-muted-foreground w-6">#{idx + 1}</span>
                      <div>
                        <div className="font-semibold text-foreground">{team.teamName}</div>
                        <div className="text-xs text-muted-foreground">
                          {formatValue(team.previousValue)} → {formatValue(team.companyValue)}
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {team.events?.map((e: string) => <EventBadge key={e} type={e} />)}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-2xl font-black ${team.valueChangePercent >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {team.valueChangePercent >= 0 ? "+" : ""}{team.valueChangePercent?.toFixed(1)}%
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {team.valueChange >= 0 ? "+" : ""}{formatValue(Math.abs(team.valueChange))}
                      </div>
                      {team.failed && (
                        <div className="text-xs text-red-400 font-medium mt-1">COLLAPSED</div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Past results */}
      {results && results.length > 0 && !showReveal && (
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Recent Simulation History</h2>
          <div className="space-y-2">
            {results.slice(-10).reverse().map(r => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-background border border-border">
                <div>
                  <span className="font-medium text-foreground text-sm">{r.teamName}</span>
                  <span className="text-xs text-muted-foreground ml-2">Round {r.round}</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {(JSON.parse(r.events) as string[]).map(e => <EventBadge key={e} type={e} />)}
                  </div>
                </div>
                <div className={`text-sm font-bold ${r.valueChange >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {r.valueChange >= 0 ? "+" : ""}{formatValue(Math.abs(r.valueChange))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
