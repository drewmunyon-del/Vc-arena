import { useState } from "react";
import { useListTeams, useCreateScore, useListScores, getListScoresQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { Check, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const CRITERIA = [
  { key: "ideaQuality", label: "Idea Quality" },
  { key: "marketOpportunity", label: "Market Opportunity" },
  { key: "businessModel", label: "Business Model" },
  { key: "competitiveAdvantage", label: "Competitive Advantage" },
  { key: "executionPlan", label: "Execution Plan" },
  { key: "presentation", label: "Presentation" },
] as const;

function ScoreSlider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-foreground">{label}</span>
        <span className={`text-sm font-bold ${value >= 7 ? "text-green-400" : value >= 4 ? "text-amber-400" : "text-red-400"}`}>
          {value}/10
        </span>
      </div>
      <div className="flex items-center gap-2">
        <input
          type="range"
          min="1"
          max="10"
          step="0.5"
          value={value}
          onChange={e => onChange(parseFloat(e.target.value))}
          className="w-full h-2 rounded-full appearance-none bg-border cursor-pointer"
          style={{
            background: `linear-gradient(to right, hsl(199 95% 55%) ${(value - 1) / 9 * 100}%, hsl(220 15% 18%) ${(value - 1) / 9 * 100}%)`,
          }}
        />
        <div className="flex gap-0.5">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
            <button
              key={n}
              onClick={() => onChange(n)}
              className={`w-5 h-5 text-xs rounded transition-all ${Math.round(value) >= n ? "text-primary" : "text-border"}`}
            >
              <Star className={`w-3 h-3 ${Math.round(value) >= n ? "fill-primary text-primary" : "text-border"}`} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function JudgePage() {
  const { currentUser } = useAuth();
  const { data: teams } = useListTeams();
  const { data: allScores } = useListScores();
  const createScore = useCreateScore();
  const queryClient = useQueryClient();

  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);
  const [scores, setScores] = useState<Record<string, number>>({
    ideaQuality: 5, marketOpportunity: 5, businessModel: 5,
    competitiveAdvantage: 5, executionPlan: 5, presentation: 5,
  });
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState<number[]>([]);

  const activeTeams = teams?.filter(t => t.status === "active" || t.status === "advanced") ?? [];
  const avg = Object.values(scores).reduce((a, b) => a + b, 0) / 6;

  async function handleSubmit() {
    if (!selectedTeamId || !currentUser) return;
    await createScore.mutateAsync({
      data: {
        teamId: selectedTeamId,
        judgeId: currentUser.id,
        round: 1,
        ...scores,
        feedback,
      }
    });
    queryClient.invalidateQueries({ queryKey: getListScoresQueryKey() });
    setSubmitted(s => [...s, selectedTeamId]);
    setSelectedTeamId(null);
    setFeedback("");
    setScores({ ideaQuality: 5, marketOpportunity: 5, businessModel: 5, competitiveAdvantage: 5, executionPlan: 5, presentation: 5 });
  }

  const scoredTeamIds = allScores
    ?.filter(s => s.judgeId === currentUser?.id)
    .map(s => s.teamId) ?? [];

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Judge Panel</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Score startups across 6 criteria (1–10)</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Team selector */}
        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Select Team</h2>
          {activeTeams.map(team => {
            const alreadyScored = scoredTeamIds.includes(team.id);
            const isSelected = selectedTeamId === team.id;
            return (
              <button
                key={team.id}
                onClick={() => !alreadyScored && setSelectedTeamId(team.id)}
                disabled={alreadyScored}
                className={`w-full p-3 rounded-xl border text-left transition-all ${
                  alreadyScored
                    ? "border-green-500/20 bg-green-500/5 opacity-60 cursor-not-allowed"
                    : isSelected
                    ? "border-primary/50 bg-primary/10"
                    : "border-border bg-card hover:border-primary/30 cursor-pointer"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-foreground text-sm">{team.name}</span>
                  {alreadyScored && <Check className="w-4 h-4 text-green-400" />}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5 truncate">{team.problem}</div>
              </button>
            );
          })}
          {activeTeams.length === 0 && (
            <div className="text-sm text-muted-foreground">No active teams to judge.</div>
          )}
        </div>

        {/* Scoring form */}
        <div className="lg:col-span-2">
          {selectedTeamId ? (
            <div className="bg-card border border-border rounded-xl p-5 space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold text-foreground">
                  Scoring: {teams?.find(t => t.id === selectedTeamId)?.name}
                </h2>
                <div className={`text-lg font-bold ${avg >= 7 ? "text-green-400" : avg >= 4 ? "text-amber-400" : "text-red-400"}`}>
                  Avg: {avg.toFixed(1)}/10
                </div>
              </div>

              <div className="space-y-4">
                {CRITERIA.map(({ key, label }) => (
                  <ScoreSlider
                    key={key}
                    label={label}
                    value={scores[key]}
                    onChange={v => setScores(s => ({ ...s, [key]: v }))}
                  />
                ))}
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-1.5">Feedback (optional)</label>
                <textarea
                  value={feedback}
                  onChange={e => setFeedback(e.target.value)}
                  placeholder="Leave detailed feedback for this team..."
                  className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary min-h-[80px] resize-none"
                />
              </div>

              <Button
                onClick={handleSubmit}
                disabled={createScore.isPending}
                className="w-full"
              >
                {createScore.isPending ? "Submitting..." : "Submit Score"}
              </Button>
            </div>
          ) : (
            <div className="bg-card border border-border rounded-xl p-8 text-center">
              <div className="text-muted-foreground">Select a team from the left to start scoring</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
