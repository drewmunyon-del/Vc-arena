import { useGetTeam, useListScores, useListSimulationResults, useUpdateTeam, getGetTeamQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, TrendingUp, TrendingDown, DollarSign, Activity } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts";
import { useState } from "react";

function formatValue(v: number) {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}

export function TeamDetail() {
  const params = useParams<{ id: string }>();
  const teamId = parseInt(params.id, 10);
  const { currentUser } = useAuth();
  const queryClient = useQueryClient();
  const isAdmin = currentUser?.role === "admin";

  const { data: team, isLoading } = useGetTeam(teamId);
  const { data: scores } = useListScores({ teamId });
  const { data: simResults } = useListSimulationResults();

  const updateTeam = useUpdateTeam();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<any>({});

  function startEdit() {
    setForm({
      name: team?.name,
      problem: team?.problem,
      solution: team?.solution,
      marketSize: team?.marketSize,
      revenueModel: team?.revenueModel,
      competitiveAdvantage: team?.competitiveAdvantage,
      riskLevel: team?.riskLevel,
    });
    setEditing(true);
  }

  async function saveEdit() {
    await updateTeam.mutateAsync({ id: teamId, data: form });
    queryClient.invalidateQueries({ queryKey: getGetTeamQueryKey(teamId) });
    setEditing(false);
  }

  const teamSimResults = simResults?.filter(r => r.teamId === teamId) ?? [];
  const chartData = teamSimResults.map(r => ({
    round: `R${r.round}`,
    value: r.companyValue / 1_000_000,
    growth: r.growthRate,
  }));

  const avgScores = scores?.length ? {
    ideaQuality: scores.reduce((s, sc) => s + sc.ideaQuality, 0) / scores.length,
    marketOpportunity: scores.reduce((s, sc) => s + sc.marketOpportunity, 0) / scores.length,
    businessModel: scores.reduce((s, sc) => s + sc.businessModel, 0) / scores.length,
    competitiveAdvantage: scores.reduce((s, sc) => s + sc.competitiveAdvantage, 0) / scores.length,
    executionPlan: scores.reduce((s, sc) => s + sc.executionPlan, 0) / scores.length,
    presentation: scores.reduce((s, sc) => s + sc.presentation, 0) / scores.length,
  } : null;

  const radarData = avgScores ? [
    { subject: "Idea", A: avgScores.ideaQuality },
    { subject: "Market", A: avgScores.marketOpportunity },
    { subject: "Business", A: avgScores.businessModel },
    { subject: "Edge", A: avgScores.competitiveAdvantage },
    { subject: "Execution", A: avgScores.executionPlan },
    { subject: "Pitch", A: avgScores.presentation },
  ] : [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!team) {
    return <div className="p-6 text-muted-foreground">Team not found.</div>;
  }

  const statusColors: Record<string, string> = {
    active: "text-green-400",
    eliminated: "text-red-400",
    winner: "text-amber-400",
    advanced: "text-cyan-400",
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <Link href="/teams">
          <button className="p-2 rounded-lg hover:bg-card text-muted-foreground hover:text-foreground transition-all">
            <ArrowLeft className="w-5 h-5" />
          </button>
        </Link>
        <div className="flex-1">
          {editing ? (
            <input
              className="text-2xl font-bold bg-transparent border-b border-primary text-foreground focus:outline-none w-full"
              value={form.name}
              onChange={e => setForm((f: any) => ({ ...f, name: e.target.value }))}
            />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">{team.name}</h1>
          )}
          <p className={`text-sm capitalize mt-0.5 ${statusColors[team.status]}`}>{team.status} · Round {team.currentRound}</p>
        </div>
        {isAdmin && !editing && (
          <button onClick={startEdit} className="px-3 py-1.5 text-sm rounded-lg border border-border text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all">
            Edit
          </button>
        )}
        {isAdmin && editing && (
          <div className="flex gap-2">
            <button onClick={() => setEditing(false)} className="px-3 py-1.5 text-sm rounded-lg border border-border text-muted-foreground hover:text-foreground transition-all">Cancel</button>
            <button onClick={saveEdit} className="px-3 py-1.5 text-sm rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-all">Save</button>
          </div>
        )}
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1">Company Value</div>
          <div className="text-xl font-bold text-primary">{formatValue(team.companyValue)}</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1">Total Funding</div>
          <div className="text-xl font-bold text-amber-400">{formatValue(team.totalFunding)}</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="text-xs text-muted-foreground mb-1">Growth Rate</div>
          <div className={`text-xl font-bold flex items-center gap-1 ${team.growthRate >= 0 ? "text-green-400" : "text-red-400"}`}>
            {team.growthRate >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {team.growthRate >= 0 ? "+" : ""}{team.growthRate.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Profile */}
      <div className="bg-card border border-border rounded-xl p-5 space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Startup Profile</h2>
        {[
          { label: "Problem", key: "problem" },
          { label: "Solution", key: "solution" },
          { label: "Market Size", key: "marketSize" },
          { label: "Revenue Model", key: "revenueModel" },
          { label: "Competitive Advantage", key: "competitiveAdvantage" },
        ].map(({ label, key }) => (
          <div key={key}>
            <div className="text-xs text-muted-foreground font-medium">{label}</div>
            {editing ? (
              <input
                className="w-full mt-0.5 px-2 py-1 rounded bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                value={form[key] ?? ""}
                onChange={e => setForm((f: any) => ({ ...f, [key]: e.target.value }))}
              />
            ) : (
              <div className="text-sm text-foreground mt-0.5">{(team as any)[key]}</div>
            )}
          </div>
        ))}
        <div>
          <div className="text-xs text-muted-foreground font-medium">Risk Level</div>
          {editing ? (
            <select
              className="mt-0.5 px-2 py-1 rounded bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              value={form.riskLevel}
              onChange={e => setForm((f: any) => ({ ...f, riskLevel: e.target.value }))}
            >
              {["low", "medium", "high", "extreme"].map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          ) : (
            <div className="text-sm text-foreground mt-0.5 capitalize">{team.riskLevel}</div>
          )}
        </div>
        <div className="grid grid-cols-2 gap-3 pt-2 border-t border-border">
          <div>
            <div className="text-xs text-muted-foreground">Confidence Score</div>
            <div className="text-lg font-bold text-foreground">{team.confidenceScore.toFixed(1)}/10</div>
          </div>
        </div>
      </div>

      {/* Value History Chart */}
      {chartData.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Value History</h2>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="valueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(199 95% 55%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(199 95% 55%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
              <XAxis dataKey="round" stroke="hsl(210 25% 55%)" tick={{ fontSize: 12 }} />
              <YAxis stroke="hsl(210 25% 55%)" tick={{ fontSize: 12 }} tickFormatter={v => `$${v}M`} />
              <Tooltip
                contentStyle={{ background: "hsl(222 20% 9%)", border: "1px solid hsl(220 15% 18%)", borderRadius: 8 }}
                formatter={(v: any) => [`$${v}M`, "Value"]}
              />
              <Area type="monotone" dataKey="value" stroke="hsl(199 95% 55%)" fill="url(#valueGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Radar chart for scores */}
      {radarData.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Score Breakdown</h2>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="hsl(220 15% 18%)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: "hsl(210 25% 55%)", fontSize: 12 }} />
              <Radar dataKey="A" stroke="hsl(199 95% 55%)" fill="hsl(199 95% 55%)" fillOpacity={0.2} />
            </RadarChart>
          </ResponsiveContainer>
          <div className="text-center text-sm text-muted-foreground mt-1">
            Average: <span className="text-foreground font-medium">{team.confidenceScore.toFixed(1)}/10</span>
          </div>
        </div>
      )}

      {/* Judge feedback */}
      {scores && scores.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Judge Feedback</h2>
          <div className="space-y-3">
            {scores.map(score => (
              <div key={score.id} className="p-3 rounded-lg bg-background border border-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">Round {score.round} · Judge #{score.judgeId}</span>
                  <span className="text-sm font-bold text-primary">{score.averageScore.toFixed(1)}/10</span>
                </div>
                {score.feedback && (
                  <p className="text-sm text-foreground/80">{score.feedback}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
