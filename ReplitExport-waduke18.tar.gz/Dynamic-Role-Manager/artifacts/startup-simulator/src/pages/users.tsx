import { useState } from "react";
import { useListUsers, useCreateUser, useUpdateUser, useDeleteUser, getListUsersQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Shield, X, KeyRound, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const roleColors: Record<string, string> = {
  admin: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  judge: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  team_member: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  viewer: "bg-slate-500/20 text-slate-400 border-slate-500/30",
};

function AddUserModal({ onClose }: { onClose: () => void }) {
  const queryClient = useQueryClient();
  const createUser = useCreateUser();
  const [form, setForm] = useState({
    name: "", email: "", password: "",
    role: "viewer" as "admin" | "judge" | "team_member" | "viewer"
  });
  const [showPass, setShowPass] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await createUser.mutateAsync({ data: { ...form, isCurrentUser: false } });
    queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">Add New User</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-3">
          <div>
            <label className="text-xs text-muted-foreground font-medium mb-1 block">Name</label>
            <input
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground font-medium mb-1 block">Email</label>
            <input
              type="email"
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground font-medium mb-1 block">Password</label>
            <div className="relative">
              <input
                type={showPass ? "text" : "password"}
                className="w-full px-3 py-2 pr-9 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder="Set a password for this user"
                required
              />
              <button type="button" onClick={() => setShowPass(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground font-medium mb-1 block">Role</label>
            <select
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              value={form.role}
              onChange={e => setForm(f => ({ ...f, role: e.target.value as any }))}
            >
              <option value="viewer">Viewer</option>
              <option value="team_member">Team Member</option>
              <option value="judge">Judge</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
            <Button type="submit" className="flex-1" disabled={createUser.isPending}>
              {createUser.isPending ? "Adding..." : "Add User"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function SetPasswordModal({ userId, userName, onClose }: { userId: number; userName: string; onClose: () => void }) {
  const queryClient = useQueryClient();
  const updateUser = useUpdateUser();
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await updateUser.mutateAsync({ id: userId, data: { password } as any });
    queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
    setDone(true);
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-sm animate-slide-up">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">Set Password</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5">
          {done ? (
            <div className="text-center py-4">
              <div className="text-green-400 text-sm font-medium">Password updated for {userName}</div>
              <Button className="mt-4 w-full" onClick={onClose}>Done</Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Set a new password for <span className="text-foreground font-medium">{userName}</span>. Share it with them directly.
              </p>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  className="w-full px-3 py-2 pr-9 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="New password"
                  required
                  autoFocus
                />
                <button type="button" onClick={() => setShowPass(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <div className="flex gap-3 pt-1">
                <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
                <Button type="submit" className="flex-1" disabled={updateUser.isPending || !password}>
                  {updateUser.isPending ? "Saving..." : "Set Password"}
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export function UsersPage() {
  const { currentUser } = useAuth();
  const { data: users, isLoading } = useListUsers();
  const updateUser = useUpdateUser();
  const deleteUser = useDeleteUser();
  const queryClient = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const [passwordUserId, setPasswordUserId] = useState<{ id: number; name: string } | null>(null);

  async function handleRoleChange(userId: number, role: string) {
    if (userId === 1 && role !== "admin") {
      alert("Cannot change the primary admin's role.");
      return;
    }
    await updateUser.mutateAsync({ id: userId, data: { role: role as any } });
    queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
  }

  async function handleDelete(userId: number) {
    if (userId === 1) {
      alert("Cannot delete the primary admin user.");
      return;
    }
    if (!confirm("Delete this user? They will no longer be able to sign in.")) return;
    await deleteUser.mutateAsync({ id: userId });
    queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
  }

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">User Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Control roles and passwords for all participants</p>
        </div>
        <Button onClick={() => setShowAdd(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add User
        </Button>
      </div>

      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3">
        <div className="flex items-start gap-2 text-amber-400 text-sm">
          <Shield className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>You control who can sign in and what they can do. Share each person's email and password with them directly — they cannot change their own role.</span>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-2">
          {users?.map(user => {
            const isCurrentUser = user.id === currentUser?.id;
            const isPrimaryAdmin = user.id === 1;
            return (
              <div
                key={user.id}
                className={cn(
                  "bg-card border rounded-xl p-4 flex items-center gap-3",
                  isCurrentUser ? "border-primary/30 bg-primary/5" : "border-border"
                )}
              >
                {/* Avatar */}
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0",
                  roleColors[user.role]
                )}>
                  {user.name.charAt(0).toUpperCase()}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-foreground">{user.name}</span>
                    {isCurrentUser && <span className="text-xs text-primary">(You)</span>}
                    {isPrimaryAdmin && <Shield className="w-3 h-3 text-amber-400" title="Primary Admin" />}
                  </div>
                  <div className="text-xs text-muted-foreground">{user.email}</div>
                </div>

                {/* Role selector */}
                <div className="flex-shrink-0">
                  {isPrimaryAdmin ? (
                    <Badge className={cn("border capitalize", roleColors[user.role])}>
                      admin
                    </Badge>
                  ) : (
                    <select
                      value={user.role}
                      onChange={e => handleRoleChange(user.id, e.target.value)}
                      className="px-2 py-1 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      <option value="viewer">Viewer</option>
                      <option value="team_member">Team Member</option>
                      <option value="judge">Judge</option>
                      <option value="admin">Admin</option>
                    </select>
                  )}
                </div>

                {/* Set password */}
                <button
                  onClick={() => setPasswordUserId({ id: user.id, name: user.name })}
                  className="p-2 text-muted-foreground hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-all flex-shrink-0"
                  title="Set password"
                >
                  <KeyRound className="w-4 h-4" />
                </button>

                {/* Delete */}
                {!isPrimaryAdmin && (
                  <button
                    onClick={() => handleDelete(user.id)}
                    className="p-2 text-muted-foreground hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showAdd && <AddUserModal onClose={() => setShowAdd(false)} />}
      {passwordUserId && (
        <SetPasswordModal
          userId={passwordUserId.id}
          userName={passwordUserId.name}
          onClose={() => setPasswordUserId(null)}
        />
      )}
    </div>
  );
}
