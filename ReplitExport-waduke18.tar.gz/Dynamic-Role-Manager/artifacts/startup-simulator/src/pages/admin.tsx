import { useState } from "react";
import { useGetCompetitionState, useUpdateCompetitionState, useResetCompetition, useListTeams, useRunSimulation, getGetCompetitionStateQueryKey, getGetDashboardSummaryQueryKey, getGetLeaderboardQueryKey, getListTeamsQueryKey, getListSimulationResultsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Settings, RotateCcw, Zap, ChevronRight, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function AdminPanel() {
  const { data: competition, isLoading } = useGetCompetitionState();
  const updateCompetition = useUpdateCompetitionState();
  const resetComp = useResetCompetition();
  const runSimulation = useRunSimulation();
  const { data: teams } = useListTeams();
  const queryClient = useQueryClient();
  const [isSimulating, setIsSimulating] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [maxRounds, setMaxRounds] = useState<number | null>(null);

  async function handleSimulate() {
    if (!competition) return;
    setIsSimulating(true);
    await runSimulation.mutateAsync({
      data: { round: competition.currentRound, intensity: competition.simulationIntensity }
    });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListSimulationResultsQueryKey() });
    setIsSimulating(false);
  }

  async function handleAdvanceRound() {
    if (!competition) return;
    const next = Math.min(competition.currentRound + 1, competition.maxRounds);
    await updateCompetition.mutateAsync({ data: { currentRound: next, status: "judging" } });
    queryClient.invalidateQueries({ queryKey: getGetCompetitionStateQueryKey() });
  }

  async function handleReset() {
    await resetComp.mutateAsync({});
    queryClient.invalidateQueries({ queryKey: getGetCompetitionStateQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListTeamsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListSimulationResultsQueryKey() });
    setConfirmReset(false);
  }

  async function handleIntensity(intensity: "low" | "medium" | "high") {
    await updateCompetition.mutateAsync({ data: { simulationIntensity: intensity } });
    queryClient.invalidateQueries({ queryKey: getGetCompetitionStateQueryKey() });
  }

  async function handleStatus(status: "setup" | "judging" | "simulating" | "results" | "completed") {
    await updateCompetition.mutateAsync({ data: { status } });
    queryClient.invalidateQueries({ queryKey: getGetCompetitionStateQueryKey() });
  }

  async function handleMaxRoundsChange(val: number) {
    setMaxRounds(val);
    await updateCompetition.mutateAsync({ data: { maxRounds: val } });
    queryClient.invalidateQueries({ queryKey: getGetCompetitionStateQueryKey() });
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const rounds = maxRounds ?? competition?.maxRounds ?? 3;
  const activeTeams = teams?.filter(t => t.status === "active").length ?? 0;

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Admin Control Panel</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Full control over the competition</p>
      </div>

      {/* Big Simulate Button */}
      <div className="bg-card border border-border rounded-2xl p-8 text-center">
        <div className="text-sm text-muted-foreground mb-2">Round {competition?.currentRound} Simulation</div>
        <button
          onClick={handleSimulate}
          disabled={isSimulating || activeTeams === 0}
          className={cn(
            "px-16 py-6 rounded-2xl text-2xl font-black tracking-wide transition-all duration-300",
            isSimulating
              ? "bg-amber-500/20 border-2 border-amber-500/50 text-amber-400 animate-pulse cursor-wait"
              : "bg-primary/10 border-2 border-primary/50 text-primary hover:bg-primary/20 hover:border-primary animate-pulse-glow cursor-pointer"
          )}
        >
          <div className="flex items-center gap-3">
            <Zap className={`w-7 h-7 ${isSimulating ? "animate-spin" : ""}`} />
            {isSimulating ? "SIMULATING..." : "RUN SIMULATION"}
          </div>
        </button>
        {activeTeams === 0 && (
          <p className="text-sm text-red-400 mt-2">No active teams to simulate</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Simulation Intensity */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Simulation Intensity</h2>
          <div className="grid grid-cols-3 gap-2">
            {(["low", "medium", "high"] as const).map(level => (
              <button
                key={level}
                onClick={() => handleIntensity(level)}
                className={cn(
                  "py-3 rounded-lg text-sm font-semibold capitalize transition-all",
                  competition?.simulationIntensity === level
                    ? level === "high" ? "bg-red-500/20 border border-red-500/40 text-red-400"
                    : level === "low" ? "bg-green-500/20 border border-green-500/40 text-green-400"
                    : "bg-amber-500/20 border border-amber-500/40 text-amber-400"
                    : "bg-muted border border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {level}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {competition?.simulationIntensity === "high"
              ? "Extreme chaos — massive swings, high failure rate"
              : competition?.simulationIntensity === "low"
              ? "Stable conditions — smaller swings, lower event chance"
              : "Balanced chaos — regular volatility, moderate events"}
          </p>
        </div>

        {/* Competition Status */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Competition Status</h2>
          <div className="grid grid-cols-2 gap-2">
            {(["setup", "judging", "simulating", "results", "completed"] as const).map(status => (
              <button
                key={status}
                onClick={() => handleStatus(status)}
                className={cn(
                  "py-2 rounded-lg text-xs font-medium capitalize transition-all",
                  competition?.status === status
                    ? "bg-primary/20 border border-primary/40 text-primary"
                    : "bg-muted border border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Round control */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Rounds</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-foreground">Current Round</span>
              <span className="text-lg font-bold text-primary">{competition?.currentRound} / {rounds}</span>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Max Rounds</label>
              <input
                type="number"
                min="1"
                max="10"
                value={rounds}
                onChange={e => handleMaxRoundsChange(parseInt(e.target.value, 10))}
                className="ml-3 w-16 px-2 py-1 rounded bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <Button
              onClick={handleAdvanceRound}
              variant="outline"
              className="w-full gap-2"
              disabled={competition?.currentRound >= rounds}
            >
              <ChevronRight className="w-4 h-4" />
              Advance to Round {(competition?.currentRound ?? 1) + 1}
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Competition Stats</h2>
          <div className="space-y-2">
            {[
              { label: "Total Teams", value: teams?.length ?? 0 },
              { label: "Active Teams", value: teams?.filter(t => t.status === "active").length ?? 0 },
              { label: "Eliminated", value: teams?.filter(t => t.status === "eliminated").length ?? 0 },
              { label: "Advanced", value: teams?.filter(t => t.status === "advanced").length ?? 0 },
            ].map(stat => (
              <div key={stat.label} className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{stat.label}</span>
                <span className="font-bold text-foreground">{stat.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reset */}
      <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-5">
        <h2 className="text-sm font-semibold text-red-400 uppercase tracking-wider mb-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          Danger Zone
        </h2>
        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="px-4 py-2 rounded-lg border border-red-500/40 text-red-400 text-sm hover:bg-red-500/10 transition-all flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Reset Competition
          </button>
        ) : (
          <div className="space-y-2">
            <p className="text-sm text-red-400">This will reset all teams, scores, and simulation results. Are you sure?</p>
            <div className="flex gap-2">
              <button
                onClick={handleReset}
                disabled={resetComp.isPending}
                className="px-4 py-2 rounded-lg bg-red-500/20 border border-red-500/40 text-red-400 text-sm hover:bg-red-500/30 transition-all"
              >
                {resetComp.isPending ? "Resetting..." : "Yes, Reset Everything"}
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-4 py-2 rounded-lg border border-border text-muted-foreground text-sm hover:text-foreground transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
