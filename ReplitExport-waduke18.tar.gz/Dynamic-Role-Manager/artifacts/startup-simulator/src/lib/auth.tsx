import React, { createContext, useContext, useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: "admin" | "judge" | "team_member" | "viewer";
  teamId?: number | null;
  createdAt: string;
}

interface AuthContextType {
  currentUser: AuthUser | null;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  login: async () => ({}),
  logout: () => {},
  isLoading: true,
});

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "").replace(/\/__replco.*/, "");

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("vc_arena_user");
    if (stored) {
      try {
        setCurrentUser(JSON.parse(stored));
      } catch {
        localStorage.removeItem("vc_arena_user");
      }
    }
    setIsLoading(false);
  }, []);

  async function login(email: string, password: string): Promise<{ error?: string }> {
    try {
      const res = await fetch(`/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        const data = await res.json();
        return { error: data.error ?? "Invalid email or password" };
      }
      const user: AuthUser = await res.json();
      setCurrentUser(user);
      localStorage.setItem("vc_arena_user", JSON.stringify(user));
      return {};
    } catch {
      return { error: "Could not connect to server. Please try again." };
    }
  }

  function logout() {
    setCurrentUser(null);
    localStorage.removeItem("vc_arena_user");
  }

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background text-primary">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
