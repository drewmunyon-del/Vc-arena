import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LayoutDashboard, Users, Building2, Award, BarChart3,
  Trophy, Settings, LogOut, Shield, Zap
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard, roles: ["admin", "judge", "team_member", "viewer"] },
  { href: "/leaderboard", label: "Leaderboard", icon: Trophy, roles: ["admin", "judge", "team_member", "viewer"] },
  { href: "/teams", label: "Teams", icon: Building2, roles: ["admin", "judge", "team_member", "viewer"] },
  { href: "/judge", label: "Judge Panel", icon: Award, roles: ["admin", "judge"] },
  { href: "/simulation", label: "Simulation", icon: BarChart3, roles: ["admin", "judge", "team_member", "viewer"] },
  { href: "/admin", label: "Admin Panel", icon: Settings, roles: ["admin"] },
  { href: "/users", label: "User Management", icon: Users, roles: ["admin"] },
];

const roleColors: Record<string, string> = {
  admin: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  judge: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  team_member: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  viewer: "bg-slate-500/20 text-slate-400 border-slate-500/30",
};

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { currentUser, logout } = useAuth();
  const [location] = useLocation();

  const visibleNav = navItems.filter(item =>
    currentUser && item.roles.includes(currentUser.role)
  );

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 flex flex-col border-r border-border bg-sidebar">
        {/* Logo */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/30 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <div>
              <div className="font-bold text-sm text-foreground leading-tight">VC Arena</div>
              <div className="text-xs text-muted-foreground">Startup Simulator</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {visibleNav.map(item => {
            const Icon = item.icon;
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={cn(
                  "flex items-center gap-2.5 px-3 py-2 rounded-md text-sm cursor-pointer transition-all",
                  isActive
                    ? "bg-primary/15 text-primary border border-primary/20"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground"
                )}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="font-medium">{item.label}</span>
                  {item.href === "/admin" && (
                    <Shield className="w-3 h-3 ml-auto text-amber-400" />
                  )}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User info */}
        <div className="p-3 border-t border-border">
          <div className="px-3 py-2 rounded-md bg-card border border-border">
            <div className="text-sm font-semibold text-foreground truncate">{currentUser?.name}</div>
            <div className="text-xs text-muted-foreground truncate">{currentUser?.email}</div>
            <Badge className={cn("text-xs mt-1 border capitalize", roleColors[currentUser?.role ?? "viewer"])}>
              {currentUser?.role?.replace("_", " ")}
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full mt-2 text-muted-foreground hover:text-foreground justify-start gap-2"
            onClick={() => logout()}
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
